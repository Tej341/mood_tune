"""Import the Spotify Million Song dataset into MoodTune.

The dataset (spotify_millsongdata.csv, ~57k songs) has artist, song, link and lyrics,
but no moods. This script tags every song from its lyrics (see mood_classifier.py)
and stores the song with its mood/activity weights. Lyrics are NOT stored.

Usage (run init_db.py first):
    python import_dataset.py                          # looks in ../data/ for the csv or zip
    python import_dataset.py path/to/archive.zip      # the zip you downloaded works too
    python import_dataset.py data.csv --limit 5000    # quick test with fewer songs

Re-running replaces the previously imported dataset songs (curated songs are kept).
"""
import argparse
import csv
import hashlib
import io
import os
import sys
import time
import zipfile

from dotenv_loader import load_env

load_env()

import db  # noqa: E402
from mood_classifier import EXCLUSIVE, Thresholds, pick_labels, score_lyrics  # noqa: E402

SOURCE = "millsong"
CSV_NAME = "spotify_millsongdata.csv"
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT_PATHS = [
    os.path.join(ROOT, "data", CSV_NAME),
    os.path.join(ROOT, "data", "archive.zip"),
    os.path.join(ROOT, "data", "spotify_millsongdata.zip"),
]

csv.field_size_limit(10_000_000)


def open_rows(path):
    """Yield dict rows from the CSV, or from the CSV inside a zip."""
    if path.lower().endswith(".zip"):
        with zipfile.ZipFile(path) as z:
            name = next((n for n in z.namelist() if n.lower().endswith(".csv")), None)
            if not name:
                sys.exit(f"No .csv file inside {path}")
            with z.open(name) as raw:
                yield from csv.DictReader(io.TextIOWrapper(raw, encoding="utf-8", newline=""))
    else:
        with open(path, encoding="utf-8", newline="") as f:
            yield from csv.DictReader(f)


def cover_color(artist):
    """Stable colour per artist so their songs look related."""
    h = int(hashlib.md5(artist.lower().encode()).hexdigest()[:6], 16)
    hue, sat, light = h % 360, 55 + (h >> 9) % 25, 45 + (h >> 17) % 15
    # HSL -> hex
    c = (1 - abs(2 * light / 100 - 1)) * sat / 100
    x = c * (1 - abs((hue / 60) % 2 - 1))
    m = light / 100 - c / 2
    r, g, b = [(c, x, 0), (x, c, 0), (0, c, x), (0, x, c), (x, 0, c), (c, 0, x)][hue // 60]
    return "#%02x%02x%02x" % tuple(round((v + m) * 255) for v in (r, g, b))


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("path", nargs="?", help="spotify_millsongdata.csv or the .zip containing it")
    ap.add_argument("--limit", type=int, default=0, help="only import the first N songs")
    args = ap.parse_args()

    path = args.path or next((p for p in DEFAULT_PATHS if os.path.exists(p)), None)
    if not path or not os.path.exists(path):
        sys.exit(f"Dataset not found. Put {CSV_NAME} (or the zip) in the data/ folder, "
                 f"or pass its path: python import_dataset.py path/to/file")

    t0 = time.time()
    print(f"Reading {path} ...")
    curated = {(r["artist"].lower(), r["title"].lower())
               for r in db.query_all("SELECT artist, title FROM songs WHERE source <> %s", (SOURCE,))}
    songs, seen = [], set(curated)
    for row in open_rows(path):
        artist, title = (row.get("artist") or "").strip(), (row.get("song") or "").strip()
        key = (artist.lower(), title.lower())
        if not artist or not title or key in seen or len(title) > 200 or len(artist) > 200:
            continue
        seen.add(key)
        songs.append((artist, title, score_lyrics(row.get("text") or "")))
        if args.limit and len(songs) >= args.limit:
            break
    print(f"  {len(songs):,} unique songs read")

    print("Tagging moods and activities from lyrics ...")
    mood_t = Thresholds([s[2][0] for s in songs])
    act_t = Thresholds([s[2][1] for s in songs])
    tagged = []
    for artist, title, (m, a) in songs:
        moods, acts = pick_labels(m, mood_t, EXCLUSIVE), pick_labels(a, act_t)
        if moods or acts:
            tagged.append((artist, title, moods, acts))
    print(f"  {len(tagged):,} songs tagged ({len(songs) - len(tagged):,} skipped: not enough mood words)")

    mood_ids = {r["name"]: r["id"] for r in db.query_all("SELECT id, name FROM moods")}
    act_ids = {r["name"]: r["id"] for r in db.query_all("SELECT id, name FROM activities")}
    if not mood_ids:
        sys.exit("No moods in the database. Run `python init_db.py` first.")

    print("Writing to the database ...")
    with db.get_db() as conn:
        cur = conn.cursor()
        # remove a previous import (cascade clears its tags and saved entries)
        cur.execute(db._sql("DELETE FROM song_moods WHERE song_id IN (SELECT id FROM songs WHERE source = %s)"), (SOURCE,))
        cur.execute(db._sql("DELETE FROM song_activities WHERE song_id IN (SELECT id FROM songs WHERE source = %s)"), (SOURCE,))
        cur.execute(db._sql("DELETE FROM saved_songs WHERE song_id IN (SELECT id FROM songs WHERE source = %s)"), (SOURCE,))
        cur.execute(db._sql("DELETE FROM songs WHERE source = %s"), (SOURCE,))
        cur.execute("SELECT COALESCE(MAX(id), 0) AS m FROM songs")
        row = cur.fetchone()
        next_id = (row["m"] if isinstance(row, dict) else row[0]) + 1

        song_rows, mood_rows, act_rows = [], [], []
        for i, (artist, title, moods, acts) in enumerate(tagged):
            sid = next_id + i
            song_rows.append((sid, title, artist, cover_color(artist), SOURCE))
            mood_rows += [(sid, mood_ids[m], w) for m, w in moods.items()]
            act_rows += [(sid, act_ids[a], w) for a, w in acts.items()]

        batches = [
            ("INSERT INTO songs (id, title, artist, cover_color, source) VALUES (%s, %s, %s, %s, %s)", song_rows),
            ("INSERT INTO song_moods (song_id, mood_id, weight) VALUES (%s, %s, %s)", mood_rows),
            ("INSERT INTO song_activities (song_id, activity_id, weight) VALUES (%s, %s, %s)", act_rows),
        ]
        for query, rows in batches:
            for start in range(0, len(rows), 5000):
                cur.executemany(db._sql(query), rows[start:start + 5000])

    print(f"Done in {time.time() - t0:.0f}s: {len(song_rows):,} songs, "
          f"{len(mood_rows):,} mood tags, {len(act_rows):,} activity tags.")


if __name__ == "__main__":
    main()
