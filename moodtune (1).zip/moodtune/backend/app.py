"""MoodTune — Flask backend (REST API).

Endpoints
  GET    /api/health
  GET    /api/moods
  GET    /api/activities
  GET    /api/recommendations?mood=Focused&activity=Studying&limit=12
  GET    /api/stats                     -> library size + songs per mood/activity
  GET    /api/songs/<id>
  GET    /api/songs/<id>/preview        -> 30-sec audio clip URL (iTunes)
  POST   /api/users                       {"username": "eklavya"}  -> get or create
  GET    /api/users/<user_id>/saved
  POST   /api/users/<user_id>/saved       {"song_id": 3}
  DELETE /api/users/<user_id>/saved/<song_id>
"""
import json
import os
import urllib.parse
import urllib.request

from dotenv_loader import load_env

load_env()

from flask import Flask, jsonify, request, send_from_directory  # noqa: E402

import db  # noqa: E402

FRONTEND_DIST = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "frontend", "dist"
)

app = Flask(__name__, static_folder=None)
ALLOWED_ORIGIN = os.getenv("CORS_ORIGIN", "*")


# ---------------------------------------------------------------- CORS
@app.after_request
def add_cors_headers(resp):
    resp.headers["Access-Control-Allow-Origin"] = ALLOWED_ORIGIN
    resp.headers["Access-Control-Allow-Headers"] = "Content-Type"
    resp.headers["Access-Control-Allow-Methods"] = "GET, POST, DELETE, OPTIONS"
    return resp


@app.route("/api/<path:_any>", methods=["OPTIONS"])
def preflight(_any):
    return "", 204


@app.errorhandler(Exception)
def handle_error(err):
    code = getattr(err, "code", 500)
    if not isinstance(code, int):
        code = 500
    if code == 500:
        app.logger.exception(err)
    return jsonify({"error": str(getattr(err, "description", err))}), code


# ---------------------------------------------------------------- helpers
SONG_COLUMNS = "s.id, s.title, s.artist, s.duration_sec, s.popularity, s.cover_color, s.preview_url, s.source"


def song_tags(song_ids):
    """Attach mood/activity names to each song (one query each, not N+1)."""
    if not song_ids:
        return {}, {}
    ph = ", ".join(["%s"] * len(song_ids))
    moods = db.query_all(
        f"SELECT sm.song_id, m.name FROM song_moods sm JOIN moods m ON m.id = sm.mood_id "
        f"WHERE sm.song_id IN ({ph}) ORDER BY sm.weight DESC", tuple(song_ids))
    acts = db.query_all(
        f"SELECT sa.song_id, a.name FROM song_activities sa JOIN activities a ON a.id = sa.activity_id "
        f"WHERE sa.song_id IN ({ph}) ORDER BY sa.weight DESC", tuple(song_ids))
    mood_map, act_map = {}, {}
    for r in moods:
        mood_map.setdefault(r["song_id"], []).append(r["name"])
    for r in acts:
        act_map.setdefault(r["song_id"], []).append(r["name"])
    return mood_map, act_map


def serialize(songs):
    mood_map, act_map = song_tags([s["id"] for s in songs])
    for s in songs:
        s["moods"] = mood_map.get(s["id"], [])
        s["activities"] = act_map.get(s["id"], [])
        for k in ("score", "mood_weight", "activity_weight"):
            if k in s and s[k] is not None:
                s[k] = int(s[k])
    return songs


# ---------------------------------------------------------------- routes
@app.get("/api/health")
def health():
    db.query_one("SELECT 1 AS ok")
    return jsonify({"status": "ok", "database": db.DB_ENGINE})


@app.get("/api/moods")
def get_moods():
    return jsonify(db.query_all("SELECT id, name, emoji FROM moods ORDER BY id"))


@app.get("/api/activities")
def get_activities():
    return jsonify(db.query_all("SELECT id, name, emoji FROM activities ORDER BY id"))


@app.get("/api/recommendations")
def recommendations():
    mood = request.args.get("mood", "").strip()
    activity = request.args.get("activity", "").strip()
    limit = min(max(request.args.get("limit", 12, type=int), 1), 50)

    if not mood and not activity:
        return jsonify({"error": "Pick a mood or an activity"}), 400
    if mood and not db.query_one("SELECT id FROM moods WHERE name = %s", (mood,)):
        return jsonify({"error": f"Unknown mood '{mood}'"}), 400
    if activity and not db.query_one("SELECT id FROM activities WHERE name = %s", (activity,)):
        return jsonify({"error": f"Unknown activity '{activity}'"}), 400

    # Recommendation logic:
    #   score = 2 x mood weight + activity weight (+2 bonus when a song fits both)
    #   Mood counts double because it matters most for how a song "feels".
    #   Ties are shuffled (RAND), so every request gives a fresh mix from a large library.
    mood_id = (db.query_one("SELECT id FROM moods WHERE name = %s", (mood,)) or {}).get("id", 0)
    act_id = (db.query_one("SELECT id FROM activities WHERE name = %s", (activity,)) or {}).get("id", 0)
    songs = db.query_all(
        f"""
        SELECT {SONG_COLUMNS},
               COALESCE(sm.weight, 0) AS mood_weight,
               COALESCE(sa.weight, 0) AS activity_weight,
               2 * COALESCE(sm.weight, 0) + COALESCE(sa.weight, 0)
                 + CASE WHEN sm.weight IS NOT NULL AND sa.weight IS NOT NULL THEN 2 ELSE 0 END
                 AS score
        FROM songs s
        LEFT JOIN song_moods sm ON sm.song_id = s.id AND sm.mood_id = %s
        LEFT JOIN song_activities sa ON sa.song_id = s.id AND sa.activity_id = %s
        WHERE sm.weight IS NOT NULL OR sa.weight IS NOT NULL
        ORDER BY score DESC, RAND()
        LIMIT %s
        """,
        (mood_id, act_id, limit),
    )
    total = db.query_one(
        """
        SELECT COUNT(*) AS n FROM (
            SELECT song_id FROM song_moods WHERE mood_id = %s
            UNION
            SELECT song_id FROM song_activities WHERE activity_id = %s
        ) t
        """,
        (mood_id, act_id),
    )["n"]
    for s in songs:
        s["match"] = "perfect" if s["mood_weight"] and s["activity_weight"] else (
            "mood" if s["mood_weight"] else "activity")
    return jsonify({"mood": mood, "activity": activity, "count": len(songs),
                    "total_matches": int(total), "songs": serialize(songs)})


@app.get("/api/stats")
def stats():
    by_source = {r["source"]: int(r["n"]) for r in
                 db.query_all("SELECT source, COUNT(*) AS n FROM songs GROUP BY source")}
    moods = {r["name"]: int(r["n"]) for r in db.query_all(
        "SELECT m.name, COUNT(*) AS n FROM song_moods sm JOIN moods m ON m.id = sm.mood_id GROUP BY m.name")}
    acts = {r["name"]: int(r["n"]) for r in db.query_all(
        "SELECT a.name, COUNT(*) AS n FROM song_activities sa JOIN activities a ON a.id = sa.activity_id "
        "GROUP BY a.name")}
    return jsonify({"songs": sum(by_source.values()), "by_source": by_source,
                    "moods": moods, "activities": acts})


@app.get("/api/songs/<int:song_id>")
def get_song(song_id):
    song = db.query_one(f"SELECT {SONG_COLUMNS} FROM songs s WHERE s.id = %s", (song_id,))
    if not song:
        return jsonify({"error": "Song not found"}), 404
    return jsonify(serialize([song])[0])


# ----- audio previews (official 30-second clips from the iTunes Search API, no key needed)
ITUNES_URL = os.getenv("ITUNES_SEARCH_URL", "https://itunes.apple.com/search")


def _itunes_preview(title, artist):
    params = urllib.parse.urlencode({"term": f"{title} {artist}", "entity": "song", "limit": 5})
    with urllib.request.urlopen(f"{ITUNES_URL}?{params}", timeout=8) as resp:
        results = json.load(resp).get("results", [])
    # prefer results whose artist and title match ours
    a_word = artist.lower().split()[0]
    t_word = title.lower().split()[0]
    results.sort(key=lambda r: (a_word not in r.get("artistName", "").lower(),
                                t_word not in r.get("trackName", "").lower()))
    for r in results:
        if r.get("previewUrl"):
            return r["previewUrl"], r.get("trackTimeMillis")
    return None, None


@app.get("/api/songs/<int:song_id>/preview")
def song_preview(song_id):
    song = db.query_one("SELECT id, title, artist, preview_url, duration_sec FROM songs WHERE id = %s",
                        (song_id,))
    if not song:
        return jsonify({"error": "Song not found"}), 404
    if song["preview_url"]:
        return jsonify({"song_id": song_id, "preview_url": song["preview_url"]})
    try:
        url, millis = _itunes_preview(song["title"], song["artist"])
    except Exception as e:  # offline, blocked, timeout
        app.logger.warning("Preview lookup failed: %s", e)
        return jsonify({"song_id": song_id, "preview_url": None, "error": "Preview service unreachable"}), 502
    duration = song["duration_sec"] or (round(millis / 1000) if millis else None)
    if url:  # cache the link (and the real song length for dataset songs)
        db.execute("UPDATE songs SET preview_url = %s, duration_sec = %s WHERE id = %s", (url, duration, song_id))
    return jsonify({"song_id": song_id, "preview_url": url, "duration_sec": duration})


# ----- optional: users + saved playlist
@app.post("/api/users")
def get_or_create_user():
    username = ((request.get_json(silent=True) or {}).get("username") or "").strip().lower()
    if not username or len(username) > 50:
        return jsonify({"error": "Username must be 1-50 characters"}), 400
    user = db.query_one("SELECT id, username FROM users WHERE username = %s", (username,))
    if not user:
        db.execute("INSERT INTO users (username) VALUES (%s)", (username,))
        user = db.query_one("SELECT id, username FROM users WHERE username = %s", (username,))
    return jsonify(user)


def _require_user(user_id):
    return db.query_one("SELECT id FROM users WHERE id = %s", (user_id,))


@app.get("/api/users/<int:user_id>/saved")
def get_saved(user_id):
    if not _require_user(user_id):
        return jsonify({"error": "User not found"}), 404
    songs = db.query_all(
        f"SELECT {SONG_COLUMNS} FROM saved_songs ss JOIN songs s ON s.id = ss.song_id "
        f"WHERE ss.user_id = %s ORDER BY ss.saved_at DESC, s.id DESC", (user_id,))
    return jsonify(serialize(songs))


@app.post("/api/users/<int:user_id>/saved")
def save_song(user_id):
    song_id = (request.get_json(silent=True) or {}).get("song_id")
    if not _require_user(user_id):
        return jsonify({"error": "User not found"}), 404
    if not isinstance(song_id, int) or not db.query_one("SELECT id FROM songs WHERE id = %s", (song_id,)):
        return jsonify({"error": "Invalid song_id"}), 400
    if not db.query_one("SELECT song_id FROM saved_songs WHERE user_id = %s AND song_id = %s",
                        (user_id, song_id)):
        db.execute("INSERT INTO saved_songs (user_id, song_id) VALUES (%s, %s)", (user_id, song_id))
    return jsonify({"saved": True, "song_id": song_id}), 201


@app.delete("/api/users/<int:user_id>/saved/<int:song_id>")
def unsave_song(user_id, song_id):
    db.execute("DELETE FROM saved_songs WHERE user_id = %s AND song_id = %s", (user_id, song_id))
    return jsonify({"saved": False, "song_id": song_id})


# ---------------------------------------------------------------- serve built React app (optional)
@app.get("/", defaults={"path": ""})
@app.get("/<path:path>")
def frontend(path):
    if path.startswith("api/"):
        return jsonify({"error": "Not found"}), 404
    if not os.path.isdir(FRONTEND_DIST):
        return jsonify({"message": "MoodTune API is running. Start the React app with `npm run dev` in /frontend."})
    full = os.path.join(FRONTEND_DIST, path)
    if path and os.path.isfile(full):
        return send_from_directory(FRONTEND_DIST, path)
    return send_from_directory(FRONTEND_DIST, "index.html")


if __name__ == "__main__":
    port = int(os.getenv("PORT", "5000"))
    print(f"MoodTune API on http://localhost:{port}  (database: {db.DB_ENGINE})")
    app.run(host="0.0.0.0", port=port, debug=os.getenv("FLASK_DEBUG", "1") == "1")
