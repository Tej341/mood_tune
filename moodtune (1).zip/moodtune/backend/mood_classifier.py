"""Lyric-based mood & activity tagging (no external libraries).

How it works
------------
1. Lyrics are split into words and each word is reduced to a rough stem
   ("dancing", "dancin'", "danced" -> "danc").
2. Every mood and activity has a keyword list (LEXICON below).
3. For each label we count keyword hits per 100 words  = the label's *density*.
4. Densities are compared with the whole dataset (percentiles), so a song gets
   weight 3 if it is in the top 10% for that label, 2 for the top 30%, 1 for the top 50%.
5. Opposite moods are exclusive (a song is Happy *or* Sad, Calm *or* Energetic),
   and each song keeps at most 2 moods and 2 activities.

It is intentionally simple and explainable. Swap `score_lyrics` for an ML model
later if you want, as long as it returns the same {label: density} dict.
"""
import re
from bisect import bisect_left

LEXICON = {
    "moods": {
        "Happy": """happy happiness joy joyful smile laugh fun sunshine sunny celebrate party
            glad cheer cheerful delight wonderful bright shine shining paradise lucky
            kiss hooray yay fantastic amazing lovely heaven blessed celebration
            dance sing smiling laughing playful bliss grin sunshiny merry""",
        "Calm": """calm peace peaceful quiet gentle soft slow still rest sleep dream breeze ocean
            river morning moon star sky float easy relax silence silent whisper hush lullaby
            tender warm cloud wave breathe serene meadow garden lake tranquil soothe slowly
            softly drift stillness evening dawn twilight""",
        "Energetic": """run fire burn power fight move jump beat fast wild loud rock scream shout
            energy electric rush crazy thunder explode ready hot shake bounce push kick faster spit flow mic
            louder higher boom bang rage rebel speed party jumping racing pump blast hype
            wildfire lightning""",
        "Sad": """sad sadness cry crying tear tears lonely alone pain hurt broken heartbreak goodbye
            lost miss missing sorrow die dead death grief cold rain dark empty regret sorry
            ache bleed weep mourn shadow wound suffer misery lonesome blue farewell gone
            forgotten fade cried tearful hopeless despair memories mistake mistakes regrets forget
            heartache brokenhearted lie lies hurts""",
        "Focused": """mind think thought focus goal believe rise climb try learn purpose plan reason
            truth wisdom understand clear path determined build become strength courage
            conquer victory win champion success ambition future destiny chase
            discipline mission vision achieve chance opportunity moment shot capture own grab""",
    },
    "activities": {
        "Studying": """think mind learn book school teach teacher lesson study read write word
            wonder quiet thought wisdom understand question answer knowledge page letter story
            remember idea imagine clear focus calm silence library""",
        "Working": """work job money boss office pay dollar hustle grind labor factory shift
            overtime rent bill cash business deal sell buy career company desk paycheck
            struggle worker working build effort sweat penny""",
        "Exercising": """run sweat gym train fight power strong stronger muscle jump beat faster push
            punch kick champion victory win energy pump move dance burn workout fit race
            running harder""",
        "Travelling": """road highway drive driving car ride mile wheel journey wander travel roam fly
            plane ship sail sea ocean map town city country west south north east border station
            bus ticket away horizon freeway rail rambling gypsy rolling cruise traveling
            travelling miles wanderer""",
        "Chilling": """relax chill easy lazy sunday beach summer sun wine beer drink smoke couch
            float breeze slow weekend vacation holiday sunset island coffee porch mellow
            hammock lounge cozy afternoon""",
    },
}

EXCLUSIVE = [("Happy", "Sad"), ("Calm", "Energetic")]
MAX_LABELS = 2
MIN_HITS = 2  # need at least this many keyword hits to get any weight

_SUFFIXES = ("ing", "in", "ed", "es", "s", "ly")
_WORD = re.compile(r"[a-z']+")


def stem(word):
    w = word.strip("'")
    for suf in _SUFFIXES:
        if w.endswith(suf) and len(w) - len(suf) >= 3:
            w = w[: -len(suf)]
            break
    if w.endswith("e") and len(w) > 3:
        w = w[:-1]
    if len(w) > 3 and w[-1] == w[-2] and w[-1] not in "aeiouls":
        w = w[:-1]  # runn -> run
    return w


STEMS = {
    group: {label: {stem(w) for w in words.split()} for label, words in labels.items()}
    for group, labels in LEXICON.items()
}


def score_lyrics(text):
    """Return ({mood: (hits, density)}, {activity: (hits, density)})."""
    tokens = [stem(t) for t in _WORD.findall(text.lower())]
    n = max(len(tokens), 50)
    out = []
    for group in ("moods", "activities"):
        res = {}
        for label, stems in STEMS[group].items():
            hits = sum(1 for t in tokens if t in stems)
            res[label] = (hits, hits * 100.0 / n)
        out.append(res)
    return out[0], out[1]


class Thresholds:
    """Percentile cut-offs per label, learned from the whole dataset."""

    CUTS = (50, 70, 90)  # -> weight 1, 2, 3

    def __init__(self, all_scores):
        self.cuts = {}
        for label in {l for s in all_scores for l in s}:
            vals = sorted(d for s in all_scores for (h, d) in [s[label]] if h >= MIN_HITS)
            if not vals:
                self.cuts[label] = (float("inf"),) * 3
                continue
            self.cuts[label] = tuple(vals[min(len(vals) - 1, len(vals) * p // 100)] for p in self.CUTS)

    def weight(self, label, hits, density):
        if hits < MIN_HITS:
            return 0
        c1, c2, c3 = self.cuts[label]
        return 3 if density >= c3 else 2 if density >= c2 else 1 if density >= c1 else 0


def pick_labels(scores, thresholds, exclusive=()):
    """{label: (hits, density)} -> {label: weight} keeping the strongest MAX_LABELS."""
    weighted = {l: (thresholds.weight(l, h, d), d) for l, (h, d) in scores.items()}
    for a, b in exclusive:
        loser = b if weighted[a][1] >= weighted[b][1] else a
        weighted[loser] = (0, 0)
    ranked = sorted(((w, d, l) for l, (w, d) in weighted.items() if w > 0), reverse=True)
    return {l: w for w, d, l in ranked[:MAX_LABELS]}
