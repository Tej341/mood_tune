"""Database connection helper.

Uses MySQL (via PyMySQL) by default. Set DB_ENGINE=sqlite to run without a
MySQL server (handy for a quick demo) — the same SQL queries work on both.
"""
import os
import sqlite3
from contextlib import contextmanager

DB_ENGINE = os.getenv("DB_ENGINE", "mysql").lower()

MYSQL_CONFIG = {
    "host": os.getenv("MYSQL_HOST", "localhost"),
    "port": int(os.getenv("MYSQL_PORT", "3306")),
    "user": os.getenv("MYSQL_USER", "root"),
    "password": os.getenv("MYSQL_PASSWORD", ""),
    "database": os.getenv("MYSQL_DATABASE", "moodtune"),
}

SQLITE_PATH = os.getenv(
    "SQLITE_PATH", os.path.join(os.path.dirname(__file__), "moodtune.db")
)


def _connect():
    if DB_ENGINE == "sqlite":
        conn = sqlite3.connect(SQLITE_PATH)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys = ON")
        return conn

    import pymysql  # imported lazily so sqlite mode needs no extra package

    return pymysql.connect(
        **MYSQL_CONFIG,
        charset="utf8mb4",
        cursorclass=pymysql.cursors.DictCursor,
        autocommit=False,
    )


def _sql(query):
    """Queries are written for MySQL; translate the two bits SQLite spells differently."""
    if DB_ENGINE != "sqlite":
        return query
    return query.replace("%s", "?").replace("RAND()", "RANDOM()")


@contextmanager
def get_db():
    conn = _connect()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def query_all(query, params=()):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute(_sql(query), params)
        return [dict(r) for r in cur.fetchall()]


def query_one(query, params=()):
    rows = query_all(query, params)
    return rows[0] if rows else None


def execute(query, params=()):
    with get_db() as conn:
        cur = conn.cursor()
        cur.execute(_sql(query), params)
        return cur.lastrowid
