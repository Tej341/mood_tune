# 🎧 MoodTune — Music Recommendation System

Tell it your mood and activity; it finds the perfect soundtrack.

**React** (frontend) → **Flask** (REST API) → **MySQL** (database)

```
moodtune/
├── backend/
│   ├── app.py            # Flask API + recommendation logic
│   ├── db.py             # MySQL connection (SQLite fallback for demos)
│   ├── init_db.py        # creates tables + loads 49 seed songs
│   ├── seed_data.py      # moods, activities, 49 hand-picked songs
│   ├── import_dataset.py # loads the Spotify Million Song dataset (~49k songs)
│   ├── mood_classifier.py# tags each dataset song's mood/activity from its lyrics
│   ├── dotenv_loader.py  # reads backend/.env
│   ├── requirements.txt
│   └── .env.example
├── database/
│   ├── schema.sql        # MySQL tables
│   └── seed.sql          # seed data as plain INSERTs
├── data/                 # put spotify_millsongdata.csv (or the zip) here
└── frontend/
    ├── package.json, vite.config.js, index.html
    └── src/
        ├── main.jsx, App.jsx, api.js, useHashRoute.js, styles.css
        ├── context/AppContext.jsx      # user, saved songs, music player state
        ├── components/  Navbar, SongCard, Player, Cover
        └── pages/       Home, Recommendations, Saved, About
```

## Requirements

- Python 3.10+
- Node.js 20.19+ (for Vite)
- MySQL 8 (or MariaDB)

## 1. Database (MySQL)

```bash
mysql -u root -p < database/schema.sql
```

## 2. Backend (Flask) — terminal 1

```bash
cd backend
python -m venv venv
# Windows: venv\Scripts\activate      Mac/Linux: source venv/bin/activate
pip install -r requirements.txt

copy .env.example .env      # Mac/Linux: cp .env.example .env
# open .env and set MYSQL_PASSWORD

python init_db.py           # creates tables + inserts the 49 starter songs
python import_dataset.py    # adds ~48,700 songs from the dataset in data/ (about 10-30 s)
python app.py               # http://localhost:5000
```

Check it: open http://localhost:5000/api/recommendations?mood=Focused&activity=Studying

`import_dataset.py` finds the dataset in the `data/` folder automatically, or you can pass a path:
`python import_dataset.py C:\Downloads\archive.zip`. Re-running it replaces the earlier import, so it's safe to run again.

> No MySQL installed? Put `DB_ENGINE=sqlite` in `backend/.env`, then run `init_db.py` and `app.py` as above. Same code, no server needed.

## 3. Frontend (React) — terminal 2

```bash
cd frontend
npm install
npm run dev                 # http://localhost:5173
```

Vite forwards `/api/*` to Flask on port 5000, so both must be running.

**Single-server option:** `npm run build` creates `frontend/dist`, and Flask serves it at http://localhost:5000.

## API

| Method | Endpoint | Purpose |
|---|---|---|
| GET | `/api/moods` | list moods |
| GET | `/api/activities` | list activities |
| GET | `/api/recommendations?mood=&activity=&limit=` | ranked songs + `total_matches` |
| GET | `/api/stats` | library size, songs per mood and activity |
| GET | `/api/songs/<id>` | one song |
| GET | `/api/songs/<id>/preview` | 30-sec audio clip URL |
| POST | `/api/users` `{"username"}` | sign in / create user |
| GET | `/api/users/<id>/saved` | saved playlist |
| POST | `/api/users/<id>/saved` `{"song_id"}` | save a song |
| DELETE | `/api/users/<id>/saved/<song_id>` | remove a song |

## How recommendations work

Each song is tagged in `song_moods` and `song_activities` with a weight (3 = perfect fit, 1 = works).

```
score = 2 × mood_weight + activity_weight  (+2 if the song fits both)
```

Mood counts double. Songs with the same score are shuffled, so **New mix** gives fresh picks from the
thousands of matches. Songs fitting both are labelled **Perfect match**.

## The dataset and how songs get their moods

The [Spotify Million Song dataset](https://www.kaggle.com/datasets/notshrirang/spotify-million-song-dataset)
has 57,650 songs by 643 artists, each with **artist, title, link and lyrics**, but **no moods**.
`import_dataset.py` tags each song from its lyrics with `mood_classifier.py`:

1. The lyrics are split into words, and each word is shortened to its stem ("dancing", "danced" → "danc").
2. Each mood and activity has a keyword list (for example *cry, lonely, goodbye* → Sad; *road, highway, miles* → Travelling).
3. Keyword hits per 100 words give the song's score for each label.
4. Scores are compared across the whole dataset. A song gets weight **3** if it is in the top 10% for that label, **2** for the top 30%, and **1** for the top 50%.
5. A song is Happy *or* Sad, and Calm *or* Energetic (whichever scores higher). It keeps at most 2 moods and 2 activities.

Result: 48,703 songs tagged. The 8,935 songs with too few mood words are skipped, and duplicates of the
starter songs are skipped too. Lyrics are used only during tagging; they are **not stored** in the database.

| Mood | Songs | | Activity | Songs |
|---|---|---|---|---|
| Happy | 13,374 | | Studying | 11,530 |
| Calm | 11,602 | | Working | 3,241 |
| Energetic | 8,706 | | Exercising | 7,951 |
| Sad | 12,956 | | Travelling | 10,846 |
| Focused | 14,170 | | Chilling | 4,062 |

Some checks: *Dancing Queen* → Happy + Exercising, *Someone Like You* → Sad, *Take It Easy* → Calm + Chilling,
*Lose Yourself* → Focused + Energetic, *Roar* → Energetic + Exercising.

**Limits:** keyword matching reads words, not meaning, so irony, metaphors and negation ("not happy") can
fool it, and the music itself (tempo, key) isn't used. To improve it, edit the word lists in
`mood_classifier.py` and re-run the import, or replace `score_lyrics()` with an ML model.

## Notes

- **Audio:** songs play inside the website. When you press play, the backend fetches the song's official 30-second preview from Apple's free iTunes Search API (no key needed) and saves the link in the `preview_url` column, so later plays load instantly. Your computer needs internet for this. Full-length songs would need a paid streaming service such as Spotify. If a song has no preview, the player shows "No preview available" and runs the progress bar without sound. You can also put your own MP3 URL in any song's `preview_url` column.
- **Add songs:** edit `backend/seed_data.py` and re-run `python init_db.py` (this resets the tables, so run `import_dataset.py` again after).
- **Song length:** the dataset has no durations. A dataset song's length is filled in from iTunes the first time it plays.
- **Users:** optional and lightweight (username only, no password), matching the "optional user accounts" in the design.
