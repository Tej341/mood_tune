Put the Spotify Million Song dataset here, either as
  spotify_millsongdata.csv
or as the zip you downloaded, renamed to
  archive.zip

Then run (after init_db.py):
  cd backend
  python import_dataset.py

The CSV is ~75 MB, so it is not included in this project zip.
