import { useEffect, useState } from "react";
import { api } from "../api.js";
import SongCard from "../components/SongCard.jsx";
import { useApp } from "../context/AppContext.jsx";

export default function Recommendations({ mood = "", activity = "" }) {
  const [songs, setSongs] = useState([]);
  const [total, setTotal] = useState(0);
  const [status, setStatus] = useState("loading");
  const [error, setError] = useState("");
  const [round, setRound] = useState(0); // bump to get a fresh mix
  const { playSong } = useApp();

  useEffect(() => {
    setStatus("loading");
    api.recommendations(mood, activity)
      .then((d) => {
        setSongs(d.songs);
        setTotal(d.total_matches || d.songs.length);
        setStatus("done");
      })
      .catch((e) => {
        setError(e.message);
        setStatus("error");
      });
  }, [mood, activity, round]);

  return (
    <section>
      <div className="page-head">
        <a href="#/" className="back" aria-label="Back">←</a>
        <div>
          <h1>Here are your recommendations</h1>
          <div className="tag-row">
            {mood && <span className="tag">{mood}</span>}
            {activity && <span className="tag">{activity}</span>}
            {status === "done" && total > 0 && (
              <span className="muted small">{total.toLocaleString()} matching songs</span>
            )}
          </div>
        </div>
        <div className="head-actions">
          <button className="chip" onClick={() => setRound((r) => r + 1)} disabled={status === "loading"}>
            ⟳ New mix
          </button>
          {songs.length > 0 && (
            <button className="cta small" onClick={() => playSong(songs[0], songs)}>▶ Play all</button>
          )}
        </div>
      </div>

      {status === "loading" && (
        <div className="song-list">
          {Array.from({ length: 5 }).map((_, i) => <div key={i} className="song-card skeleton" />)}
        </div>
      )}
      {status === "error" && <div className="alert">{error}</div>}
      {status === "done" && songs.length === 0 && (
        <div className="empty">No songs match that yet. <a href="#/">Try another mood</a>.</div>
      )}
      {status === "done" && (
        <div className="song-list">
          {songs.map((s, i) => <SongCard key={s.id} song={s} list={songs} rank={i + 1} />)}
        </div>
      )}
    </section>
  );
}
