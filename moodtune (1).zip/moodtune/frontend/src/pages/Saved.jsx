import { useState } from "react";
import SongCard from "../components/SongCard.jsx";
import { useApp } from "../context/AppContext.jsx";

export default function Saved() {
  const { user, login, saved, playSong } = useApp();
  const [name, setName] = useState("");
  const [error, setError] = useState("");

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    try {
      await login(name);
      setName("");
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <section>
      <div className="page-head">
        <div>
          <h1>Your saved songs</h1>
          <p className="muted">Playlist for <strong>{user?.username || "…"}</strong> · stored in the database</p>
        </div>
        {saved.length > 0 && (
          <button className="cta small" onClick={() => playSong(saved[0], saved)}>▶ Play all</button>
        )}
      </div>

      <form className="user-form" onSubmit={submit}>
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Switch user (e.g. priya)" maxLength={50} />
        <button className="chip" type="submit" disabled={!name.trim()}>Switch</button>
      </form>
      {error && <div className="alert">{error}</div>}

      {saved.length === 0 ? (
        <div className="empty">No saved songs yet. Tap ♡ on any recommendation to save it.</div>
      ) : (
        <div className="song-list">
          {saved.map((s) => <SongCard key={s.id} song={s} list={saved} />)}
        </div>
      )}
    </section>
  );
}
