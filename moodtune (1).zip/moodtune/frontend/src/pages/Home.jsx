import { useEffect, useState } from "react";
import { api } from "../api.js";
import { navigate } from "../useHashRoute.js";

export default function Home() {
  const [moods, setMoods] = useState([]);
  const [activities, setActivities] = useState([]);
  const [mood, setMood] = useState(null);
  const [activity, setActivity] = useState(null);
  const [error, setError] = useState("");
  const [stats, setStats] = useState(null);

  useEffect(() => {
    Promise.all([api.moods(), api.activities()])
      .then(([m, a]) => {
        setMoods(m);
        setActivities(a);
      })
      .catch(() => setError("Can't reach the backend. Is Flask running on port 5000?"));
    api.stats().then(setStats).catch(() => {});
  }, []);

  const go = () => navigate("/recommendations", { mood: mood || "", activity: activity || "" });

  return (
    <section className="home">
      <div className="hero">
        <p className="eyebrow">Music Recommendation System</p>
        <h1>How are you feeling today?</h1>
        <p className="lead">Tell us your mood and what you're doing. We'll find the perfect soundtrack. ♫</p>
        {stats && (
          <p className="library-line">
            <strong>{stats.songs.toLocaleString()}</strong> songs in the library
            {stats.by_source?.millsong ? " · tagged from the Spotify Million Song dataset" : ""}
          </p>
        )}
      </div>

      {error && <div className="alert">{error}</div>}

      <div className="panel">
        <h2 className="panel-title"><span className="step">1</span>Pick your mood</h2>
        <div className="mood-grid">
          {moods.map((m) => (
            <button key={m.id} className={`mood-card ${mood === m.name ? "selected" : ""}`}
                    onClick={() => setMood(mood === m.name ? null : m.name)} aria-pressed={mood === m.name}>
              <span className="mood-emoji">{m.emoji}</span>
              <span>{m.name}</span>
              {stats?.moods?.[m.name] ? (
                <span className="count">{stats.moods[m.name].toLocaleString()}</span>
              ) : null}
            </button>
          ))}
        </div>

        <h2 className="panel-title"><span className="step">2</span>What are you doing?</h2>
        <div className="chip-row">
          {activities.map((a) => (
            <button key={a.id} className={`chip ${activity === a.name ? "selected" : ""}`}
                    onClick={() => setActivity(activity === a.name ? null : a.name)} aria-pressed={activity === a.name}>
              <span>{a.emoji}</span> {a.name}
            </button>
          ))}
        </div>

        <button className="cta" disabled={!mood && !activity} onClick={go}>
          {mood || activity
            ? `Get Recommendations${mood ? ` · ${mood}` : ""}${activity ? ` · ${activity}` : ""}`
            : "Pick a mood or activity"}
        </button>
      </div>
    </section>
  );
}
