const FLOW = [
  ["User selects mood & activity", "Chosen in the React UI, e.g. Focused + Studying."],
  ["React sends an API request", "GET /api/recommendations?mood=…&activity=… to Flask."],
  ["Flask processes the request", "Validates input and runs the recommendation query."],
  ["MySQL returns matching songs", "Songs are scored by how well they fit the mood and activity."],
  ["Flask sends a JSON response", "The ranked list goes back to the frontend."],
  ["React displays recommendations", "Songs appear with a music player and a save button."],
];

const STACK = [
  ["⚛️", "React", "Components, state, routing"],
  ["🎨", "CSS", "Layout, responsive design, animations"],
  ["🟨", "JavaScript", "API calls, event handling"],
  ["🐍", "Python + Flask", "REST API, recommendation logic"],
  ["🐬", "MySQL", "Songs, moods, activities, users"],
  ["📚", "Dataset", "Spotify Million Song, tagged from lyrics"],
];

export default function About() {
  return (
    <section className="about">
      <h1>How MoodTune works</h1>
      <p className="lead">
        Each song in the database is tagged with the moods and activities it fits, each with a weight
        from 1 to 3. A song's score is <code>2 × mood weight + activity weight</code>, plus a bonus of 2
        when it fits both. The top-scoring songs are your recommendations, shuffled so each visit
        brings a new mix.
      </p>

      <h2>The song library</h2>
      <p className="lead">
        Besides a hand-picked starter set, the library holds songs from the <strong>Spotify Million Song
        dataset</strong> (57,650 songs by 643 artists). That dataset has lyrics but no moods, so each song
        was tagged automatically when it was imported. Its lyrics are matched against keyword lists for each
        mood and activity (for example <em>cry, lonely, goodbye</em> for Sad, or <em>road, highway,
        miles</em> for Travelling). A song gets weight 3 if it is in the top 10% for that mood, 2 for the
        top 30%, and 1 for the top 50%. Songs with too few mood words are left out. The lyrics are only
        used for tagging and are never stored.
      </p>

      <h2>Flow of the app</h2>
      <ol className="flow">
        {FLOW.map(([t, d], i) => (
          <li key={t}><span className="step">{i + 1}</span><div><strong>{t}</strong><p>{d}</p></div></li>
        ))}
      </ol>

      <h2>Tech stack</h2>
      <div className="stack-grid">
        {STACK.map(([icon, name, desc]) => (
          <div key={name} className="stack-card">
            <span className="stack-icon">{icon}</span>
            <strong>{name}</strong>
            <span className="muted">{desc}</span>
          </div>
        ))}
      </div>
    </section>
  );
}
