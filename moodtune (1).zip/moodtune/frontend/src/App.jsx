import Navbar from "./components/Navbar.jsx";
import Player from "./components/Player.jsx";
import Home from "./pages/Home.jsx";
import Recommendations from "./pages/Recommendations.jsx";
import Saved from "./pages/Saved.jsx";
import About from "./pages/About.jsx";
import { useHashRoute } from "./useHashRoute.js";
import { useApp } from "./context/AppContext.jsx";

export default function App() {
  const { path, params } = useHashRoute();
  const { current } = useApp();

  let page;
  if (path === "/recommendations") page = <Recommendations mood={params.mood} activity={params.activity} />;
  else if (path === "/saved") page = <Saved />;
  else if (path === "/about") page = <About />;
  else page = <Home />;

  return (
    <div className={`app ${current ? "has-player" : ""}`}>
      <div className="bg-glow" aria-hidden="true" />
      <Navbar path={path} />
      <main className="container">{page}</main>
      <Player />
    </div>
  );
}
