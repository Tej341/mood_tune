import { createContext, useCallback, useContext, useEffect, useRef, useState } from "react";
import { api } from "../api.js";

const AppContext = createContext(null);
export const useApp = () => useContext(AppContext);

function readStoredName() {
  try {
    return localStorage.getItem("moodtune:user") || "guest";
  } catch {
    return "guest";
  }
}

export function AppProvider({ children }) {
  // ---------- user + saved songs (optional accounts)
  const [user, setUser] = useState(null);
  const [saved, setSaved] = useState([]);

  const login = useCallback(async (username) => {
    const u = await api.login(username);
    setUser(u);
    try { localStorage.setItem("moodtune:user", u.username); } catch { /* storage unavailable */ }
    setSaved(await api.saved(u.id));
    return u;
  }, []);

  useEffect(() => {
    login(readStoredName()).catch(() => {});
  }, [login]);

  const isSaved = (id) => saved.some((s) => s.id === id);

  const toggleSave = async (song) => {
    if (!user) return;
    if (isSaved(song.id)) {
      setSaved((list) => list.filter((s) => s.id !== song.id));
      await api.unsave(user.id, song.id);
    } else {
      setSaved((list) => [song, ...list]);
      await api.save(user.id, song.id);
    }
  };

  // ---------- music player
  const [queue, setQueue] = useState([]);
  const [index, setIndex] = useState(-1);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [audioLen, setAudioLen] = useState(0);
  // songId -> preview URL, or null when no preview exists / service unreachable
  const [previews, setPreviews] = useState({});
  const audioRef = useRef(null);
  const current = queue[index] || null;

  const previewUrl = current ? current.preview_url || previews[current.id] : undefined;
  // "loading" while we ask the backend, "audio" for a real clip, "demo" for simulated playback
  const audioStatus = !current ? null
    : previewUrl ? "audio"
    : previews[current.id] === null ? "demo"
    : "loading";
  // dataset songs may have no known length until their preview loads
  const duration = audioStatus === "audio" ? audioLen || 30 : current?.duration_sec || 30;

  const playSong = (song, list = [song]) => {
    const i = list.findIndex((s) => s.id === song.id);
    if (current?.id === song.id) {
      setIsPlaying((p) => !p);
      return;
    }
    setQueue(list);
    setIndex(i < 0 ? 0 : i);
    setProgress(0);
    setIsPlaying(true);
  };

  const next = useCallback(() => {
    setProgress(0);
    setIndex((i) => (queue.length ? (i + 1) % queue.length : -1));
  }, [queue.length]);

  const prev = () => {
    if (progress > 3) return seek(0);
    setProgress(0);
    setIndex((i) => (queue.length ? (i - 1 + queue.length) % queue.length : -1));
  };

  const seek = (sec) => {
    setProgress(sec);
    if (audioRef.current && audioStatus === "audio") audioRef.current.currentTime = sec;
  };

  // Look up the song's audio preview through the backend
  useEffect(() => {
    if (!current || current.preview_url || current.id in previews) return;
    let cancelled = false;
    api.preview(current.id)
      .then((r) => !cancelled && setPreviews((m) => ({ ...m, [current.id]: r.preview_url || null })))
      .catch(() => !cancelled && setPreviews((m) => ({ ...m, [current.id]: null })));
    return () => { cancelled = true; };
  }, [current, previews]);

  // Real audio, played in the page
  useEffect(() => {
    if (!audioRef.current) {
      audioRef.current = new Audio();
      audioRef.current.preload = "auto";
    }
    const a = audioRef.current;
    if (audioStatus !== "audio") {
      a.pause();
      return;
    }
    if (a.src !== previewUrl) {
      a.src = previewUrl;
      setAudioLen(0);
      setProgress(0);
    }
    a.ontimeupdate = () => setProgress(a.currentTime);
    a.onloadedmetadata = () => setAudioLen(a.duration || 30);
    a.onended = next;
    a.onerror = () => setPreviews((m) => ({ ...m, [current.id]: null }));
    isPlaying ? a.play().catch(() => setIsPlaying(false)) : a.pause();
  }, [audioStatus, previewUrl, isPlaying, next, current]);

  // Simulated playback when a song has no preview
  useEffect(() => {
    if (!isPlaying || audioStatus !== "demo") return;
    const t = setInterval(() => {
      setProgress((p) => {
        if (p + 1 >= duration) {
          next();
          return 0;
        }
        return p + 1;
      });
    }, 1000);
    return () => clearInterval(t);
  }, [isPlaying, audioStatus, duration, next]);

  const value = {
    user, login, saved, isSaved, toggleSave,
    current, queue, isPlaying, progress, duration, audioStatus,
    playSong, togglePlay: () => setIsPlaying((p) => !p), next, prev, seek,
  };
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}
