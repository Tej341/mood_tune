// All calls to the Flask backend live here.
// In dev Vite proxies /api -> http://localhost:5000 (see vite.config.js).
// Set VITE_API_URL if the backend is hosted somewhere else.
const BASE = (import.meta.env?.VITE_API_URL || "") + "/api";

async function request(path, options = {}) {
  const res = await fetch(BASE + path, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

export const api = {
  moods: () => request("/moods"),
  activities: () => request("/activities"),
  recommendations: (mood, activity) =>
    request(`/recommendations?${new URLSearchParams({ mood, activity })}`),
  stats: () => request("/stats"),
  preview: (songId) => request(`/songs/${songId}/preview`),
  login: (username) =>
    request("/users", { method: "POST", body: JSON.stringify({ username }) }),
  saved: (userId) => request(`/users/${userId}/saved`),
  save: (userId, songId) =>
    request(`/users/${userId}/saved`, { method: "POST", body: JSON.stringify({ song_id: songId }) }),
  unsave: (userId, songId) =>
    request(`/users/${userId}/saved/${songId}`, { method: "DELETE" }),
};

export function formatTime(sec) {
  const s = Math.max(0, Math.floor(sec));
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
}
