// Generated album art: a gradient from the song's colour plus its initials.
export default function Cover({ song, size = 56 }) {
  const initials = song.title
    .replace(/[^\p{L}\p{N} ]/gu, "")
    .split(" ")
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0])
    .join("")
    .toUpperCase();
  return (
    <div
      className="cover"
      style={{
        width: size,
        height: size,
        fontSize: size * 0.32,
        background: `radial-gradient(circle at 30% 25%, ${song.cover_color}ee, ${song.cover_color}55 55%, #0b0a1f 100%)`,
      }}
      aria-hidden="true"
    >
      {initials}
    </div>
  );
}
