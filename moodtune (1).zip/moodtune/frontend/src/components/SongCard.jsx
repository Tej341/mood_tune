import Cover from "./Cover.jsx";
import { formatTime } from "../api.js";
import { useApp } from "../context/AppContext.jsx";

const MATCH_LABEL = { perfect: "Perfect match", mood: "Mood match", activity: "Activity match" };

export default function SongCard({ song, list, rank }) {
  const { current, isPlaying, playSong, isSaved, toggleSave } = useApp();
  const active = current?.id === song.id;
  const saved = isSaved(song.id);

  return (
    <div className={`song-card ${active ? "active" : ""}`}>
      {rank && <span className="rank">{rank}</span>}
      <Cover song={song} />
      <div className="song-info">
        <div className="song-title">{song.title}</div>
        <div className="song-artist">{song.artist}</div>
        <div className="song-meta">
          {song.duration_sec ? <span>{formatTime(song.duration_sec)}</span> : null}
          {song.match && <span className={`match match-${song.match}`}>{MATCH_LABEL[song.match]}</span>}
        </div>
      </div>
      <button className={`icon-btn heart ${saved ? "on" : ""}`} onClick={() => toggleSave(song)}
              aria-label={saved ? "Remove from saved" : "Save song"} title={saved ? "Saved" : "Save"}>
        {saved ? "♥" : "♡"}
      </button>
      <button className="play-btn" onClick={() => playSong(song, list)}
              aria-label={active && isPlaying ? "Pause" : "Play"}>
        {active && isPlaying ? "❚❚" : "▶"}
      </button>
    </div>
  );
}
