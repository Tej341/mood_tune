import { useState } from "react";
import { useApp } from "../context/AppContext.jsx";

const LINKS = [
  { href: "#/", label: "Home", match: (p) => p === "/" || p === "/recommendations" },
  { href: "#/saved", label: "Saved", match: (p) => p === "/saved" },
  { href: "#/about", label: "About", match: (p) => p === "/about" },
];

export default function Navbar({ path }) {
  const { user, saved } = useApp();
  const [open, setOpen] = useState(false);

  return (
    <header className="navbar">
      <div className="container nav-inner">
        <a href="#/" className="brand" onClick={() => setOpen(false)}>
          <span className="brand-icon">🎧</span>
          <span>Mood<span className="accent">Tune</span></span>
        </a>
        <button className="menu-btn" aria-label="Menu" onClick={() => setOpen((o) => !o)}>☰</button>
        <nav className={`nav-links ${open ? "open" : ""}`}>
          {LINKS.map((l) => (
            <a key={l.href} href={l.href} onClick={() => setOpen(false)}
               className={l.match(path) ? "active" : ""}>
              {l.label}
              {l.label === "Saved" && saved.length > 0 && <span className="badge">{saved.length}</span>}
            </a>
          ))}
          {user && <span className="user-chip" title="Signed in as">👤 {user.username}</span>}
        </nav>
      </div>
    </header>
  );
}
