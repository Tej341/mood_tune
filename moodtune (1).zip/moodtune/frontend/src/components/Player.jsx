import Cover from "./Cover.jsx";
import { formatTime } from "../api.js";
import { useApp } from "../context/AppContext.jsx";

export default function Player() {
  const { current, isPlaying, progress, duration, audioStatus, togglePlay, next, prev, seek, isSaved, toggleSave } = useApp();
  if (!current) return null;

  const pct = duration ? (progress / duration) * 100 : 0;
  const STATUS = { loading: "Loading audio…", audio: "30-sec preview", demo: "No preview available" };

  return (
    <div className="player">
      <div className="container player-inner">
        <div className="player-song">
          <Cover song={current} size={46} />
          <div className="song-info">
            <div className="song-title">{current.title}</div>
            <div className="song-artist">{current.artist}</div>
          </div>
        </div>

        <div className="player-center">
          <div className="controls">
            <button className="icon-btn" onClick={prev} aria-label="Previous">⏮</button>
            <button className="play-btn big" onClick={togglePlay} aria-label={isPlaying ? "Pause" : "Play"}>
              {isPlaying ? "❚❚" : "▶"}
            </button>
            <button className="icon-btn" onClick={next} aria-label="Next">⏭</button>
          </div>
          <div className="progress-row">
            <span>{formatTime(progress)}</span>
            <input type="range" min="0" max={duration} value={Math.floor(progress)}
                   onChange={(e) => seek(Number(e.target.value))}
                   style={{ "--pct": `${pct}%` }} aria-label="Seek" />
            <span>{formatTime(duration)}</span>
          </div>
        </div>

        <div className="player-right">
          <button className={`icon-btn heart ${isSaved(current.id) ? "on" : ""}`}
                  onClick={() => toggleSave(current)} aria-label="Save">
            {isSaved(current.id) ? "♥" : "♡"}
          </button>
          <span className={`audio-status status-${audioStatus}`}>{STATUS[audioStatus]}</span>
        </div>
      </div>
    </div>
  );
}
