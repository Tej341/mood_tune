-- MoodTune — MySQL schema
-- Run:  mysql -u root -p < database/schema.sql
-- Then seed it with:  python backend/init_db.py   (or import database/seed.sql)
-- Add the Spotify Million Song dataset with:  python backend/import_dataset.py

CREATE DATABASE IF NOT EXISTS moodtune CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE moodtune;

DROP TABLE IF EXISTS saved_songs;
DROP TABLE IF EXISTS song_activities;
DROP TABLE IF EXISTS song_moods;
DROP TABLE IF EXISTS users;
DROP TABLE IF EXISTS songs;
DROP TABLE IF EXISTS activities;
DROP TABLE IF EXISTS moods;

CREATE TABLE moods (
    id    INT AUTO_INCREMENT PRIMARY KEY,
    name  VARCHAR(50) NOT NULL UNIQUE,
    emoji VARCHAR(16) NOT NULL
);

CREATE TABLE activities (
    id    INT AUTO_INCREMENT PRIMARY KEY,
    name  VARCHAR(50) NOT NULL UNIQUE,
    emoji VARCHAR(16) NOT NULL
);

CREATE TABLE songs (
    id           INT AUTO_INCREMENT PRIMARY KEY,
    title        VARCHAR(200) NOT NULL,
    artist       VARCHAR(200) NOT NULL,
    duration_sec INT NULL,                       -- filled from the audio preview for dataset songs
    popularity   INT NULL,
    cover_color  VARCHAR(7) NOT NULL DEFAULT '#7c3aed',
    preview_url  VARCHAR(500) NULL,
    source       VARCHAR(20) NOT NULL DEFAULT 'curated'  -- 'curated' or 'millsong' (Spotify Million Song dataset)
);

-- Which moods a song fits (weight 1-3)
CREATE TABLE song_moods (
    song_id INT NOT NULL,
    mood_id INT NOT NULL,
    weight  TINYINT NOT NULL DEFAULT 1,
    PRIMARY KEY (song_id, mood_id),
    FOREIGN KEY (song_id) REFERENCES songs(id) ON DELETE CASCADE,
    FOREIGN KEY (mood_id) REFERENCES moods(id) ON DELETE CASCADE
);

-- Which activities a song fits (weight 1-3)
CREATE TABLE song_activities (
    song_id     INT NOT NULL,
    activity_id INT NOT NULL,
    weight      TINYINT NOT NULL DEFAULT 1,
    PRIMARY KEY (song_id, activity_id),
    FOREIGN KEY (song_id) REFERENCES songs(id) ON DELETE CASCADE,
    FOREIGN KEY (activity_id) REFERENCES activities(id) ON DELETE CASCADE
);

-- Speed up "songs for this mood / activity" lookups
CREATE INDEX idx_song_moods_mood ON song_moods (mood_id, weight);
CREATE INDEX idx_song_activities_activity ON song_activities (activity_id, weight);
CREATE INDEX idx_songs_source ON songs (source);

-- Optional: users and their saved playlist
CREATE TABLE users (
    id         INT AUTO_INCREMENT PRIMARY KEY,
    username   VARCHAR(50) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE saved_songs (
    user_id  INT NOT NULL,
    song_id  INT NOT NULL,
    saved_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, song_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (song_id) REFERENCES songs(id) ON DELETE CASCADE
);
